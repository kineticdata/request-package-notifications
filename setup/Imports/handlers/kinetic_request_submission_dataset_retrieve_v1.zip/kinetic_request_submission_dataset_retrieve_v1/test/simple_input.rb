{
  'info' => {
    'server'         => '',
    'username'       => '',
    'password'       => '',
    'port'           => '3000',
    'prognum'        => '0',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'CustomerSurveyInstanceID'  => '',
  } 
}