{
  'info' => {
    'server'         => '',
    'username'       => '',
    'password'       => '',
    'port'           => '',
    'prognum'        => '0',
    'authentication' => '',
    'enable_debug_logging' => 'No'
  },
  'parameters' => {
    'messagename' => '',
    'region' => ''
  } 
}