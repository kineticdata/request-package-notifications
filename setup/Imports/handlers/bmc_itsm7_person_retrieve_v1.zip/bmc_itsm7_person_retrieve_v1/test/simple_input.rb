{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '0',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'remedy_login_id' => ''
  }
}