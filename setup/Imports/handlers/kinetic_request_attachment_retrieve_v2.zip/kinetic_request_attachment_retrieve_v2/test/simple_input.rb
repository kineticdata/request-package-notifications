{
  'info' => {
    'server'               => "",
    'username'             => "",
    'password'             => "",
    'port'                 => "",
    'prognum'              => "0",
    'authentication'       => "",
    'enable_debug_logging' => "Yes"
  },
  'parameters' => {
    'content_type'                   => "Plain",
    'attachment_question_menu_label' => "attachment",
    'customer_survey_instance_id' => "AG000C29DAE499SoNFVAb8NKEg7T8K",
    'survey_template_instance_id' => "KS9b3b82a299983f700f9cccec68b089b87"
  }
}

