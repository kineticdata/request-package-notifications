{
  'info' => {
    'server'   => '',
    'username' => '',
    'password' => '',
    'port'     => '',
    'prognum'  => '0',
    'authentication' => ''
  },
  'parameters' => {
    'catalog_name'      => '',
    'service_item_name' => '',
    'attribute_name'    => ''
  }
}