{
  'info' => {
    'server'         => '',
    'username'       => '',
    'password'       => '',
    'port'           => '',
    'prognum'        => '0',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'Submission ID' => ''
  } 
}